package Thiago.Ceolin.ProjPokedex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjPokedexApplicationTests {

	@Test
	void contextLoads() {
	}

}
