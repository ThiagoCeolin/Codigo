package thiago.ceolin.iplace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IplaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(IplaceApplication.class, args);
	}

}
