package thiago.ceolin.iplace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IplaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
