package Thiago.Ceolin.ProjStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
